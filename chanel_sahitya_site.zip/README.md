# Chanel Sahitya Website

This is a static site for Chanel Sahitya, fully ready to publish on GitHub Pages.

## How to publish
1. Create a GitHub repository.
2. Upload `index.html` (and any other assets).
3. Go to Settings → Pages → Source → `main` branch → `/ (root)` folder → Save.
4. Your site will be live at: `https://<username>.github.io/<repo-name>/`.
